const demoFixtures = [
  ['demo-1', '13:30', 'Tottenham', 'West Ham', 'England · Premier League'],
  ['demo-2', '16:00', 'Real Madrid', 'Villarreal', 'Spain · La Liga']
].map(([id, time, home, away, league]) => ({ id, time, home, away, league, country: league.split(' · ')[0], demo: true, status: 'NS' }));

// Never expose demo data as if it were a football calendar.
let fixtures = [];
let selected = null;
let fixturesLoading = false;
let liveOnly = false;
let signalMarket = 'Все';
let matchSearch = '';
const finishedStatuses = new Set(['FT', 'AET', 'PEN']);
const liveStatuses = new Set(['1H', 'HT', '2H', 'ET', 'BT', 'P', 'LIVE', 'INP']);
const hiddenStatuses = new Set(['PST', 'CANC', 'ABD', 'SUSP']);
const scheduledMatchWindowMs = 2 * 60 * 60 * 1000;
const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
const countrySearchAliases = {
  England: 'англия английская', Scotland: 'шотландия', Wales: 'уэльс', 'Northern Ireland': 'северная ирландия',
  Portugal: 'португалия', Spain: 'испания', France: 'франция', Germany: 'германия', Italy: 'италия',
  Netherlands: 'нидерланды голландия', Belgium: 'бельгия', Austria: 'австрия', Switzerland: 'швейцария',
  Denmark: 'дания', Sweden: 'швеция', Norway: 'норвегия', Finland: 'финляндия', Poland: 'польша',
  Ireland: 'ирландия', 'Republic of Ireland': 'ирландия', Belarus: 'беларусь белоруссия', Ukraine: 'украина',
  Russia: 'россия', Turkey: 'турция', Greece: 'греция', Romania: 'румыния', Serbia: 'сербия', Croatia: 'хорватия',
  Brazil: 'бразилия', Argentina: 'аргентина', Mexico: 'мексика', 'United States': 'сша америка'
};
function matchSearchText(match) {
  const country = String(match.country || '');
  return `${match.home || ''} ${match.away || ''} ${match.league || ''} ${country} ${countrySearchAliases[country] || ''}`.toLocaleLowerCase('ru');
}

function importance(match) {
  const league = String(match.league || '').toLowerCase();
  if (league.includes('uefa nations league')) return 1000;
  if (league.includes('world cup') || league.includes('euro')) return 980;
  if (league.includes('copa america') || league.includes('africa cup')) return 940;
  if (league.includes('concacaf nations league')) return 900;
  if (league.includes('champions league')) return 850;
  if (league.includes('premier league') || league.includes('la liga') || league.includes('serie a') || league.includes('bundesliga') || league.includes('ligue 1')) return 780;
  return 100;
}
const europeanCountries = new Set([
  'Albania', 'Andorra', 'Armenia', 'Austria', 'Azerbaijan', 'Belarus', 'Belgium', 'Bosnia and Herzegovina', 'Bulgaria', 'Croatia', 'Cyprus', 'Czech-Republic', 'Czech Republic', 'Denmark', 'England', 'Estonia', 'Faroe-Islands', 'Faroe Islands', 'Finland', 'France', 'Georgia', 'Germany', 'Gibraltar', 'Greece', 'Hungary', 'Iceland', 'Ireland', 'Israel', 'Italy', 'Kosovo', 'Latvia', 'Liechtenstein', 'Lithuania', 'Luxembourg', 'Malta', 'Moldova', 'Montenegro', 'Netherlands', 'North-Macedonia', 'North Macedonia', 'Northern-Ireland', 'Northern Ireland', 'Norway', 'Poland', 'Portugal', 'Republic-of-Ireland', 'Republic of Ireland', 'Romania', 'Russia', 'San-Marino', 'San Marino', 'Scotland', 'Serbia', 'Slovakia', 'Slovenia', 'Spain', 'Sweden', 'Switzerland', 'Turkey', 'Ukraine', 'Wales'
]);
function competitionRegion(match) {
  const league = String(match.league || '').toLowerCase();
  const country = String(match.country || 'Международный турнир');
  const national = /world cup|euro|nations league|qualification|friendl/i.test(league) && !/club world cup|club championship/i.test(league);
  if (national) return { rank: 1, label: 'Сборные' };
  if (europeanCountries.has(country)) return { rank: 0, label: 'Европейские клубные лиги' };
  if (/argentina|brazil|bolivia|chile|colombia|ecuador|paraguay|peru|uruguay|venezuela/i.test(country)) return { rank: 2, label: 'Южная Америка' };
  if (/canada|costa rica|el salvador|guatemala|honduras|jamaica|mexico|nicaragua|panama|united states/i.test(country)) return { rank: 3, label: 'Северная и Центральная Америка' };
  if (/algeria|angola|cameroon|egypt|ghana|kenya|morocco|nigeria|senegal|south africa|tunisia/i.test(country)) return { rank: 5, label: 'Африка' };
  return { rank: 4, label: country === 'World' ? 'Международные клубные турниры' : 'Азия и Океания' };
}
function isLive(match) { return liveStatuses.has(match.status); }
function isFinished(match) { return finishedStatuses.has(match.status); }
function activeFixtures() {
  const now = Date.now();
  return fixtures.filter(match => {
    if (isFinished(match) || hiddenStatuses.has(match.status)) return false;
    if (isLive(match)) return true;
    const kickoff = new Date(match.kickoff).getTime();
    // A provider can temporarily leave a started match as NS. Do not let an
    // old scheduled entry stay on the active screen for the whole day.
    return !Number.isFinite(kickoff) || kickoff > now - scheduledMatchWindowMs;
  });
}
function timeOf(match) { return match.time || new Intl.DateTimeFormat('ru-RU', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Bratislava' }).format(new Date(match.kickoff)); }
function dateOf(match) {
  if (!match.kickoff) return 'Демо-календарь';
  return new Intl.DateTimeFormat('ru-RU', { day: '2-digit', month: 'long', weekday: 'short', timeZone: 'Europe/Bratislava' }).format(new Date(match.kickoff));
}
function scoreOf(match) {
  if (Number.isFinite(match.home_goals) || Number.isFinite(match.away_goals)) return `${match.home_goals ?? 0} : ${match.away_goals ?? 0}`;
  return '— : —';
}
function sourceOf(match) { return match.data_provider || 'API-Football'; }
function statusOf(match) {
  if (isLive(match)) return match.elapsed ? `LIVE · ${match.elapsed}′` : 'LIVE';
  if (isFinished(match)) return 'Завершён';
  if (match.status === 'PST') return 'Перенесён';
  if (match.status === 'CANC') return 'Отменён';
  return `Начало ${timeOf(match)}`;
}
function activate(id) {
  document.querySelectorAll('.page').forEach(page => page.classList.toggle('active', page.id === id));
  document.querySelectorAll('.nav-item[data-page]').forEach(button => button.classList.toggle('active', button.dataset.page === id));
  document.getElementById('crumb-title').textContent = ({ dashboard: 'ОБЗОР', matches: 'ВСЕ МАТЧИ', signals: 'РЕКОМЕНДАЦИИ', performance: 'ПРОВЕРКА МОДЕЛИ', 'match-detail': 'АНАЛИЗ МАТЧА' })[id] || 'MATCHTRUTH';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function statusCard(name, description) {
  return `<article class="market-card unavailable-market"><div class="market-top"><span>${escapeHtml(name)}</span><span class="coverage-label">ОЖИДАНИЕ</span></div><div class="market-value"><strong>—</strong><span class="not-valid">НЕТ ЦИФР БЕЗ ФАКТОВ</span></div><p>${escapeHtml(description)}</p></article>`;
}
function renderSelected() {
  const m = selected;
  if (!m) {
    document.getElementById('selected-match').innerHTML = '<div class="empty-state"><h2>Календарь пока не загружен.</h2><p>Сайт ждёт фактические данные из локального кэша или источника матчей.</p></div>';
    document.getElementById('market-grid').innerHTML = '';
    return;
  }
  document.getElementById('selected-match').innerHTML = `<div class="match-main"><div class="league-line"><span class="flag">⚽</span>${escapeHtml(m.league)} <i></i> ${escapeHtml(dateOf(m))}, ${escapeHtml(timeOf(m))}</div><div class="clubs"><div class="club home"><div class="crest arsenal">${escapeHtml(m.home[0])}</div><strong>${escapeHtml(m.home)}</strong><small>Хозяева</small></div><div class="versus"><span>${scoreOf(m)}</span><small>${escapeHtml(statusOf(m))}</small></div><div class="club away"><div class="crest chelsea">${escapeHtml(m.away[0])}</div><strong>${escapeHtml(m.away)}</strong><small>Гости</small></div></div><div class="match-meta"><span><i class="dot green"></i>${escapeHtml(dateOf(m))} · ${escapeHtml(timeOf(m))}</span><span><i class="dot amber"></i>${escapeHtml(statusOf(m))}</span><span><i class="dot"></i>Источник: ${escapeHtml(sourceOf(m))}</span><span><i class="dot"></i>Расчёт — только при достаточных фактах</span></div></div><div class="outcome-panel"><span class="panel-label">ОТКРЫТЬ АНАЛИЗ</span><div class="pending-panel">В карточке матча показаны источники, выборка и отдельные рынки. Общая цифра для чужих команд не используется.</div><button class="analyse-btn" data-open="${escapeHtml(m.id)}">Анализ матча <span>→</span></button></div>`;
  document.getElementById('market-grid').innerHTML = ['Исход матча (1X2)', 'Голы: больше / меньше', 'Угловые', 'Карточки'].map(name => statusCard(name, 'Откройте матч: система проверит персональную историю команд.')).join('');
}
function listSignal(m) {
  // The calendar must answer the user's first question immediately: what is
  // the strongest specific outcome for this exact match, and how probable is
  // it? The detail view still exposes every market behind this headline.
  if (m.top_market) return `Авторасчёт: ${m.top_market.label} · ${m.top_market.probability}%`;
  if (m.calculation_summary?.outcome_and_goals) {
    const extra = [m.calculation_summary.corners ? 'угловые' : null, m.calculation_summary.cards ? 'карточки' : null].filter(Boolean);
    return `Расчёт: 1X2 и голы${extra.length ? ` + ${extra.join(', ')}` : ''}`;
  }
  if (m.calculation_coverage === 'competition_or_global_prior') return 'PASS — недостаточно истории команд';
  return 'Расчёт формируется…';
}
function renderList() {
  const active = activeFixtures();
  const scope = liveOnly ? active.filter(isLive) : active;
  const query = matchSearch.trim().toLocaleLowerCase('ru');
  const visible = query ? scope.filter(match => matchSearchText(match).includes(query)) : scope;
  const groups = Object.values(visible.reduce((result, fixture) => {
    const key = `${fixture.country || 'Международный турнир'}::${fixture.league || 'Неизвестная лига'}`;
    (result[key] ||= []).push(fixture);
    return result;
  }, {})).sort((a, b) => {
    const regionOrder = competitionRegion(a[0]).rank - competitionRegion(b[0]).rank;
    return regionOrder || Math.max(...b.map(importance)) - Math.max(...a.map(importance)) || String(a[0].country || '').localeCompare(String(b[0].country || ''), 'ru') || String(a[0].league || '').localeCompare(String(b[0].league || ''), 'ru');
  });
  const renderGroup = group => {
    const first = group[0], region = competitionRegion(first), country = first.country || 'Международный турнир', league = first.league || 'Неизвестная лига';
    const matches = group.sort((a, b) => importance(b) - importance(a) || Number(isLive(b)) - Number(isLive(a)) || new Date(a.kickoff) - new Date(b.kickoff));
    return `<section class="league-group"><div class="league-group-title"><small>${escapeHtml(region.label)} · ${escapeHtml(country)}</small><strong>${escapeHtml(league)}</strong><span>${group.length} матч.</span></div>${matches.map(m => `<article class="list-match ${m.id === selected.id ? 'selected' : ''}" data-open="${escapeHtml(m.id)}"><div class="time">${isLive(m) ? '● LIVE' : escapeHtml(timeOf(m))}<small>${escapeHtml(dateOf(m))}</small></div><div class="teams"><b>${escapeHtml(m.home)}</b><span class="score">${scoreOf(m)}</span><b>${escapeHtml(m.away)}</b><small>${escapeHtml(country)} · ${escapeHtml(league)} · ${escapeHtml(statusOf(m))}</small></div><div class="list-signal"><span>Статус анализа</span><b>${escapeHtml(listSignal(m))}</b></div><div class="data-pill"><i></i>${isFinished(m) ? 'итог' : isLive(m) ? 'идёт сейчас' : 'ожидается'}</div><span class="arrow">→</span></article>`).join('')}</section>`;
  };
  document.getElementById('match-list').innerHTML = groups.length ? groups.map(renderGroup).join('') : (query ? `<div class="empty-state"><div class="empty-icon">⌕</div><h2>По запросу «${escapeHtml(matchSearch.trim())}» матчей не найдено.</h2><p>Попробуйте страну, лигу или часть названия команды.</p></div>` : liveOnly ? '<div class="empty-state"><h2>Сейчас нет live-матчей.</h2><p>Нажмите «Показать все матчи», чтобы вернуться к календарю.</p></div>' : '<div class="empty-state"><h2>Календарь временно недоступен.</h2><p>Нажмите «Обновить»: сайт не будет подменять реальные матчи демонстрационными.</p></div>');
  ['fixture-count', 'nav-fixture-count'].forEach(id => document.getElementById(id).textContent = active.length);
}
function recommendationQuality(match) {
  return match.calculation_coverage === 'team_history_available'
    ? { title: 'ИСТОРИЯ КОМАНД', note: 'Расчёт использует персональную историю обеих команд.', rank: 2 }
    : { title: 'ПРОФИЛЬ ТУРНИРА', note: 'Предварительная оценка: персональной истории пары пока недостаточно.', rank: 1 };
}
function renderSignals() {
  const holder = document.getElementById('recommendations-content');
  if (!holder) return;
  const perMatchMarket = new Map();
  for (const match of activeFixtures()) {
    // Recommendations are only for an actual calculation of this pair.
    // A league-wide average belongs in diagnostics, not in a recommendation.
    if (match.calculation_coverage !== 'team_history_available' || isLive(match)) continue;
    if (!match.recommendation_options?.length) continue;
    for (const option of match.recommendation_options || []) {
      // TБ/ТМ 1.5 stays visible in the complete goal table of the match,
      // but it is deliberately not used as a universal headline recommendation.
      if (['ТБ 1.5', 'ТМ 1.5'].includes(option.label)) continue;
      if (Number(option.probability) < 75) continue;
      if (signalMarket !== 'Все' && option.market !== signalMarket) continue;
      // In the main list each match appears once: its most probable available
      // market. This makes 94% appear before 93%, 90%, 89% and so on instead
      // of hiding a match because another market was chosen first.
      const key = match.id;
      const current = perMatchMarket.get(key);
      if (!current || Number(option.probability) > Number(current.option.probability)) perMatchMarket.set(key, { match, option, quality: recommendationQuality(match) });
    }
  }
  const candidates = [...perMatchMarket.values()].sort((a, b) => Number(b.option.probability) - Number(a.option.probability) || b.quality.rank - a.quality.rank || importance(b.match) - importance(a.match));
  const filter = `<div class="signal-filter">${['Все', 'Исход', 'Голы', 'Угловые', 'Карточки'].map(market => `<button class="${signalMarket === market ? 'active' : ''}" data-signal-market="${market}">${market}${market === 'Все' ? ` <b>${candidates.length}</b>` : ''}</button>`).join('')}</div>`;
  if (!candidates.length) {
    const stillPreparing = fixturesLoading || !fixtures.length || activeFixtures().some(match => ['pending', 'available_on_open'].includes(match.calculation_status));
    if (stillPreparing) {
      holder.innerHTML = `${filter}<div class="empty-state"><div class="empty-icon">✦</div><p class="eyebrow">РАСЧЁТЫ ПОДГОТАВЛИВАЮТСЯ</p><h2>Календарь уже загружен, а рекомендации ещё собираются.</h2><p>Готовые варианты появятся здесь автоматически. Уже показанные рекомендации не удаляются во время фонового обновления.</p></div>`;
      return;
    }
    holder.innerHTML = `${filter}<div class="empty-state"><div class="empty-icon">✦</div><p class="eyebrow">НЕТ ВАРИАНТА ВЫШЕ 75%</p><h2>Сейчас система не нашла сильного события в выбранной категории.</h2><p>Ни один активный матч не достиг порога 75% по этому рынку.</p></div>`;
    return;
  }
  holder.innerHTML = `${filter}<div class="recommendation-summary"><span>Вариантов от 75%: <b>${candidates.length}</b></span><small>Сортировка: вероятность по убыванию → качество данных → важность матча</small></div><div class="recommendation-list">${candidates.map(({ match, option, quality }, index) => `<article class="recommendation-card" data-open="${escapeHtml(match.id)}"><div class="recommendation-rank">${index + 1}</div><div class="recommendation-match"><p>${escapeHtml(match.league)} · ${escapeHtml(dateOf(match))}, ${escapeHtml(timeOf(match))}</p><h2>${escapeHtml(match.home)} <span>${scoreOf(match)}</span> ${escapeHtml(match.away)}</h2><small>${escapeHtml(statusOf(match))} · Источник: ${escapeHtml(sourceOf(match))}</small></div><div class="recommendation-signal"><small>${escapeHtml(option.market)}</small><span>${escapeHtml(option.label)}</span><b>${escapeHtml(option.probability)}%</b></div><div class="recommendation-quality quality-${quality.rank}"><b>${quality.title}</b><small>${quality.note}</small></div><span class="arrow">→</span></article>`).join('')}</div>`;
}
function overviewMatchCard(match, kind) {
  const live = kind === 'live';
  return `<article class="overview-match-card ${live ? 'is-live' : ''}" data-open="${escapeHtml(match.id)}"><p>${live ? `● LIVE${match.elapsed ? ` · ${match.elapsed}′` : ''}` : escapeHtml(match.league)}</p><h3>${escapeHtml(match.home)} <span>${scoreOf(match)}</span> ${escapeHtml(match.away)}</h3><small>${live ? escapeHtml(match.league) : `${escapeHtml(dateOf(match))} · ${escapeHtml(timeOf(match))}`} · ${escapeHtml(statusOf(match))}</small><b>Открыть анализ →</b></article>`;
}
function renderDashboard() {
  const liveHolder = document.getElementById('overview-live');
  const priorityHolder = document.getElementById('overview-priority');
  const signalHolder = document.getElementById('overview-signals');
  if (!liveHolder || !priorityHolder || !signalHolder) return;
  const current = activeFixtures();
  const live = current.filter(isLive).sort((a, b) => Number(b.elapsed || 0) - Number(a.elapsed || 0));
  const priority = current.sort((a, b) => importance(b) - importance(a) || new Date(a.kickoff) - new Date(b.kickoff)).slice(0, 6);
  const strong = current.filter(match => match.top_market && match.calculation_coverage === 'team_history_available' && Number(match.top_market.probability) >= 65).sort((a, b) => Number(b.top_market.probability) - Number(a.top_market.probability)).slice(0, 3);
  const calculated = current.filter(match => match.top_market).length;
  document.getElementById('overview-calculated').textContent = calculated || '—';
  document.getElementById('overview-strong').textContent = strong.length || '—';
  liveHolder.innerHTML = live.length ? live.slice(0, 4).map(match => overviewMatchCard(match, 'live')).join('') : '<div class="overview-empty">Сейчас нет матчей в live. Здесь автоматически появятся счёт и минута, когда игра начнётся.</div>';
  priorityHolder.innerHTML = priority.length ? priority.map(match => overviewMatchCard(match, 'priority')).join('') : '<div class="overview-empty">Главные матчи появятся после загрузки календаря.</div>';
  signalHolder.innerHTML = strong.length ? strong.map(match => `<article class="overview-signal-card" data-open="${escapeHtml(match.id)}"><p>${escapeHtml(match.league)} · ${escapeHtml(match.home)} — ${escapeHtml(match.away)}</p><h3>${escapeHtml(match.top_market.label)} <b>${escapeHtml(match.top_market.probability)}%</b></h3><small>История обеих команд · ${escapeHtml(statusOf(match))}</small></article>`).join('') : '<div class="overview-empty">Нет сильного варианта с достаточной историей команд. Предварительные оценки доступны в карточках матчей.</div>';
}
function renderPerformance() {
  const holder = document.getElementById('performance-content');
  if (!holder) return;
  const current = activeFixtures();
  const calculated = current.filter(match => match.top_market);
  const teamHistory = calculated.filter(match => match.calculation_coverage === 'team_history_available');
  const preliminary = calculated.length - teamHistory.length;
  holder.innerHTML = `<div class="performance-notice"><span>◉</span><div><b>Проверка честности: калибровка на завершённых матчах ещё не завершена</b><p>Система считает вероятности и показывает покрытие данных, но пока не называет их гарантией, точностью или готовым финансовым советом.</p></div></div><div class="model-check-grid"><article><span>АКТИВНЫХ МАТЧЕЙ</span><b>${current.length}</b><small>предстоящие и live-матчи из API-Football</small></article><article><span>РАСЧЁТОВ ГОТОВО</span><b>${calculated.length}</b><small>матчей с уже рассчитанным главным событием</small></article><article><span>С ИСТОРИЕЙ КОМАНД</span><b>${teamHistory.length}</b><small>более сильное персональное покрытие</small></article><article><span>ПРЕДВАРИТЕЛЬНЫХ</span><b>${preliminary}</b><small>расчёт по профилю соревнования</small></article></div><section class="validation-plan"><p class="eyebrow">СЛЕДУЮЩАЯ ОБЯЗАТЕЛЬНАЯ ПРОВЕРКА</p><h2>Backtest на уже сыгранных матчах</h2><p>Модель будет строить прогноз до известного результата, затем сравнивать его с фактом. Только после этого здесь появятся подтверждённые показатели: точность вероятностей, ошибки по голам, угловым и карточкам.</p><div><span>1. Зафиксировать прогноз до матча</span><span>2. Сверить с фактическим итогом</span><span>3. Откалибровать коэффициенты</span></div></section>`;
}
function valueCard(title, status, rows, note) {
  return `<article class="market-card"><div class="market-top"><span>${title}</span><span class="coverage-label">${status}</span></div><div class="market-value"><strong>${rows[0][1]}</strong><span class="not-valid">ОЦЕНКА</span></div><div class="bar-pair">${rows.map(([, value]) => `<div><b style="width:${Math.min(100, Number.parseFloat(value) || 0)}%"></b></div>`).join('')}</div><div class="market-bottom">${rows.map(([label, value]) => `<span>${label}: ${value}</span>`).join('')}</div><p>${note}</p></article>`;
}
function marketRows(probabilities, labels) { return Object.entries(labels).map(([key, label]) => [label, `${probabilities[key]}%`]); }
function renderCalculatedMarkets(w) {
  const p = w.probabilities, c = w.corners?.probabilities, k = w.cards?.probabilities;
  const preliminary = w.coverage === 'competition_or_global_prior';
  const cornerPreliminary = preliminary || w.corners?.coverage === 'competition_prior';
  const cardPreliminary = preliminary || w.cards?.coverage === 'competition_prior';
  const coverageLabel = preliminary ? 'ПРЕДВАРИТЕЛЬНО' : 'ИСТОРИЯ КОМАНД';
  const eventEvidenceLabel = cornerPreliminary ? `${w.corners?.sample?.total || 0} ФАКТОВ · ТУРНИР` : `${w.corners?.sample?.total || 0} ФАКТОВ`;
  const cardEvidenceLabel = cardPreliminary ? `${w.cards?.sample?.total || 0} ФАКТОВ · ТУРНИР` : `${w.cards?.sample?.total || 0} ФАКТОВ`;
  const outcomeCard = valueCard('Исход матча (1X2)', coverageLabel, marketRows(p, { home_win: 'Победа хозяев', draw: 'Ничья', away_win: 'Победа гостей' }), preliminary ? 'Предварительная оценка по фактическому профилю турнира; уточняется с накоплением истории этой пары.' : 'Форма, дом/выезд, сила соперников и распределение счёта.');
  const goalsCard = valueCard('Голы', coverageLabel, marketRows(p, { over_1_5: 'ТБ 1.5', under_1_5: 'ТМ 1.5', over_2_5: 'ТБ 2.5', under_2_5: 'ТМ 2.5', btts_yes: 'Обе забьют — да', btts_no: 'Обе забьют — нет' }), preliminary ? 'Предварительная оценка по фактическим матчам турнира.' : 'Отдельно показаны оба направления каждого тотала.');
  const cornerFacts = w.corners?.sample || { home: 0, away: 0 };
  const cardFacts = w.cards?.sample || { home: 0, away: 0 };
  const cornersCard = c ? valueCard('Угловые', eventEvidenceLabel, marketRows(c, { 'over_7.5': 'ТБ 7.5', 'under_7.5': 'ТМ 7.5', 'over_8.5': 'ТБ 8.5', 'under_8.5': 'ТМ 8.5', 'over_9.5': 'ТБ 9.5', 'under_9.5': 'ТМ 9.5', 'over_10.5': 'ТБ 10.5', 'under_10.5': 'ТМ 10.5' }), `${cornerPreliminary ? 'Предварительный расчёт по фактической статистике турнира' : 'Персональная событийная модель'}. Ожидаемый тотал: ${w.corners.mean}.`) : statusCard('Угловые', `PASS — факты угловых: хозяева ${cornerFacts.home}/4, гости ${cornerFacts.away}/4. Сбор событийной статистики продолжается.`);
  const cardsCard = k ? valueCard('Карточки', cardEvidenceLabel, marketRows(k, { 'over_2.5': 'ТБ 2.5', 'under_2.5': 'ТМ 2.5', 'over_3.5': 'ТБ 3.5', 'under_3.5': 'ТМ 3.5', 'over_4.5': 'ТБ 4.5', 'under_4.5': 'ТМ 4.5', 'over_5.5': 'ТБ 5.5', 'under_5.5': 'ТМ 5.5' }), `${cardPreliminary ? 'Предварительный расчёт по фактической статистике турнира' : 'Персональная событийная модель'}. Ожидаемый тотал: ${w.cards.mean}.`) : statusCard('Карточки', `PASS — факты карточек: хозяева ${cardFacts.home}/4, гости ${cardFacts.away}/4. Сбор событийной статистики продолжается.`);
  document.getElementById('detail-markets').innerHTML = `<section class="analysis-command"><div><p class="eyebrow">МНОГОФАКТОРНЫЙ РАСЧЁТ MATCHTRUTH</p><h2>${escapeHtml(w.strongest_market.label)}: <em>${w.strongest_market.probability}%</em></h2></div><div class="coverage-grid"><span><b>${w.sample.home}</b> матчей хозяев</span><span><b>${w.sample.away}</b> матчей гостей</span><span><b>${w.sample.total_historical_matches}</b> матчей в базе</span><span><b>НЕ КАЛИБРОВАНО</b> статус</span></div></section><section class="market-group"><header class="group-title"><span class="group-icon">◈</span><div><p>ОСНОВНЫЕ РЫНКИ</p><h2>Исход и голы</h2></div></header><div class="detail-markets">${outcomeCard}${goalsCard}</div></section><section class="market-group"><header class="group-title"><span class="group-icon">▦</span><div><p>СОБЫТИЯ МАТЧА</p><h2>Угловые и карточки</h2></div></header><div class="detail-markets">${cornersCard}${cardsCard}</div></section>`;
}
function renderDetail() {
  const m = selected;
  if (!m) {
    document.getElementById('detail-title').textContent = 'Матч не выбран';
    document.getElementById('detail-meta').textContent = 'Сначала должен загрузиться фактический календарь.';
    document.getElementById('analysis-result').innerHTML = '';
    document.getElementById('detail-markets').innerHTML = '';
    return;
  }
  document.getElementById('detail-title').innerHTML = `${escapeHtml(m.home)} <span>${scoreOf(m)}</span> ${escapeHtml(m.away)}`;
  document.getElementById('detail-meta').textContent = `${m.league} · ${dateOf(m)}, ${timeOf(m)} · ${statusOf(m)} · Источник: ${sourceOf(m)}`;
  document.getElementById('detail-markets').innerHTML = '';
  document.getElementById('analysis-result').innerHTML = '';
  document.getElementById('why-title').textContent = 'Статус: сбор фактических данных';
  if (!m.demo && m.provider_fixture_id) loadAnalysis(m);
}
function renderUnifiedPrediction(prediction) {
  const holder = document.getElementById('analysis-result');
  const quality = `${Number(prediction.data_quality || 0)}% данных`;
  const confidence = prediction.confidence?.level || 'LOW';
  if (prediction.status === 'insufficient_data') {
    const acquisitionError = String(prediction.acquisition?.error || '');
    const providerLimited = acquisitionError.includes('429');
    document.getElementById('why-title').textContent = 'Статус: недостаточно данных для персонального расчёта';
    holder.innerHTML = `<section class="own-analysis evidence-panel"><p>ЕДИНЫЙ РАСЧЁТНЫЙ КОНТУР</p><h2>${providerLimited ? 'Источник временно ограничил запросы' : 'Процент не опубликован'}</h2><small>${providerLimited ? 'Внешний спортивный API исчерпал лимит запросов (HTTP 429). Система не подменяет недоступные факты средними по лиге и не рисует прогноз.' : `Для расчёта нужны минимум ${prediction.features?.evidence?.result_minimum || 8} завершённых матчей каждой команды. Отсутствующие сведения не заменяются средними значениями турнира.`}</small></section>`;
    document.getElementById('detail-markets').innerHTML = `<section class="market-group"><header class="group-title"><span class="group-icon">◈</span><div><p>КОНТРОЛЬ ДАННЫХ</p><h2>Что доступно сейчас</h2></div></header><div class="detail-markets">${statusCard('Результаты и форма', `Хозяева: ${prediction.snapshot?.data_completeness?.results?.home_matches || 0}; гости: ${prediction.snapshot?.data_completeness?.results?.away_matches || 0}.`)}${statusCard('Событийная статистика', `Угловые: ${prediction.snapshot?.data_completeness?.events?.corners_matches || 0}; карточки: ${prediction.snapshot?.data_completeness?.events?.cards_matches || 0}.`)}</div></section>`;
    return;
  }
  const preliminaryResults = Boolean(prediction.features?.evidence?.result_preliminary);
  document.getElementById('why-title').textContent = preliminaryResults ? 'Статус: предварительный расчёт по малой выборке' : 'Статус: единый расчёт по персональной истории команд';
  holder.innerHTML = `<section class="own-analysis"><p>UNIVERSAL PREDICTION ENGINE · ${escapeHtml(prediction.model_version)}</p><h2>${preliminaryResults ? 'Предварительный расчёт по официальной истории команд' : 'Расчёт построен из единого MatchSnapshot'}</h2><small>${preliminaryResults ? `Найдена малая, но реальная выборка: хозяева ${prediction.features.teams.home.goals.sample} матчей, гости ${prediction.features.teams.away.goals.sample}. Исход и голы показаны как предварительная модельная оценка; в рекомендации такой расчёт не попадает.` : `Качество данных: ${quality}. Confidence: ${confidence}. Калибровка ещё не обучена — результаты показаны как модельная оценка, без рекомендации.`}</small></section>`;
  const outcomes = valueCard('Исход матча (1X2)', quality, marketRows(prediction.outcomes, { home: 'Победа хозяев', draw: 'Ничья', away: 'Победа гостей' }), `Ожидаемые голы: ${prediction.goals.expected_home} — ${prediction.goals.expected_away}.`);
  const goals = valueCard('Голы и BTTS', 'POISSON 0:0–8:8', marketRows(prediction.goal_markets.totals, { 'over_1.5': 'ТБ 1.5', 'under_1.5': 'ТМ 1.5', 'over_2.5': 'ТБ 2.5', 'under_2.5': 'ТМ 2.5' }), `Обе забьют — да: ${prediction.goal_markets.btts_yes}%.`);
  const cornerEvidence = `${prediction.corner_markets.sample.home} + ${prediction.corner_markets.sample.away} фактов${prediction.corner_markets.sample.head_to_head ? ` + ${prediction.corner_markets.sample.head_to_head} очных` : ''}`;
  const cardEvidence = `${prediction.card_markets.sample.home} + ${prediction.card_markets.sample.away} фактов${prediction.card_markets.sample.head_to_head ? ` + ${prediction.card_markets.sample.head_to_head} очных` : ''}`;
  const corners = prediction.corner_markets.markets
    ? valueCard('Угловые', cornerEvidence, marketRows(prediction.corner_markets.markets, { 'over_7.5': 'ТБ 7.5', 'under_7.5': 'ТМ 7.5', 'over_9.5': 'ТБ 9.5', 'under_9.5': 'ТМ 9.5' }), `Ожидаемый тотал: ${prediction.corner_markets.expected_total}. Основа: ${prediction.corner_markets.basis === 'team_history_plus_last_4_head_to_head' ? 'история команд + 4 последние очные встречи' : 'история конкретных команд'}.`)
    : statusCard('Угловые', `Недостаточно фактов по обеим командам: ${prediction.corner_markets.sample.home}/${prediction.features.evidence.event_minimum} и ${prediction.corner_markets.sample.away}/${prediction.features.evidence.event_minimum}.`);
  const cards = prediction.card_markets.markets
    ? valueCard('Карточки', cardEvidence, marketRows(prediction.card_markets.markets, { 'over_2.5': 'ТБ 2.5', 'under_2.5': 'ТМ 2.5', 'over_4.5': 'ТБ 4.5', 'under_4.5': 'ТМ 4.5' }), `Ожидаемый тотал: ${prediction.card_markets.expected_total}. Основа: ${prediction.card_markets.basis === 'team_history_plus_last_4_head_to_head' ? 'история команд + 4 последние очные встречи' : 'история конкретных команд'}.`)
    : statusCard('Карточки', `Недостаточно фактов по обеим командам: ${prediction.card_markets.sample.home}/${prediction.features.evidence.event_minimum} и ${prediction.card_markets.sample.away}/${prediction.features.evidence.event_minimum}.`);
  document.getElementById('detail-markets').innerHTML = `<section class="market-group"><header class="group-title"><span class="group-icon">◈</span><div><p>РАСПРЕДЕЛЕНИЯ</p><h2>Голы и исход</h2></div></header><div class="detail-markets">${outcomes}${goals}</div></section><section class="market-group"><header class="group-title"><span class="group-icon">▦</span><div><p>СОБЫТИЙНЫЕ МОДЕЛИ</p><h2>Угловые и карточки</h2></div></header><div class="detail-markets">${corners}${cards}</div></section>`;
}
async function loadAnalysis(match) {
  const holder = document.getElementById('analysis-result');
  holder.innerHTML = '<div class="analysis-loading">MatchTruth проверяет персональную историю команд…</div>';
  try {
    const response = await fetch(`/api/analysis/${encodeURIComponent(match.provider_fixture_id)}`, { cache: 'no-store' });
    const data = await response.json(); if (!response.ok) throw new Error(data.error);
    if (data.universal_prediction) { renderUnifiedPrediction(data.universal_prediction); return; }
    let w = data.warehouse_prediction;
    if (w?.status === 'calculated_with_prior' || w?.coverage === 'competition_or_global_prior') {
      document.getElementById('why-title').textContent = 'Статус: предварительный расчёт по фактическому профилю турнира';
      holder.innerHTML = `<section class="own-analysis evidence-panel"><p>ПРЕДВАРИТЕЛЬНЫЙ РАСЧЁТ MATCHTRUTH</p><h2>Угловые и карточки рассчитаны для этой пары</h2><small>По хозяевам найдено: ${Number(w.sample?.home || 0)} матчей; по гостям: ${Number(w.sample?.away || 0)}. Пока персональной истории недостаточно, система использует фактические матчи соответствующего турнира и помечает все значения ниже как предварительные. Когда накопится история обеих команд, расчёт автоматически переключится на персональную модель.</small></section>`;
      renderCalculatedMarkets(w);
      return;
    }
    if (!w || w.status === 'insufficient_team_evidence' || w.status === 'pass') {
      document.getElementById('why-title').textContent = 'Статус: нет подтверждённой истории этой пары';
      holder.innerHTML = `<section class="own-analysis evidence-panel"><p>КОНТРОЛЬ ВХОДНЫХ ДАННЫХ</p><h2>Общий процент не подставлен</h2><small>${escapeHtml(w?.reason || 'Нет подтверждённых данных для расчёта.')}</small></section>`;
      document.getElementById('detail-markets').innerHTML = `<section class="market-group"><header class="group-title"><span class="group-icon">◈</span><div><p>ТРЕБУЕМЫЕ ФАКТОРЫ</p><h2>Что нужно для расчёта этой пары</h2></div></header><div class="detail-markets">${(w?.required_inputs || ['история результатов и формы', 'состав и отсутствующие игроки', 'угловые и карточки', 'погода, поле и судья']).map(item => statusCard(item, 'Факт не загружен — выдуманная вероятность не публикуется.')).join('')}</div></section>`;
      return;
    }
    if (w.status === 'experimental_unvalidated' || w.status === 'calculated_with_prior') {
      document.getElementById('why-title').textContent = 'Статус: есть история команд, калибровка продолжается';
      holder.innerHTML = `<section class="own-analysis"><p>САМОСТОЯТЕЛЬНЫЙ РАСЧЁТ · ${escapeHtml(w.model)}</p><h2>Расчёт построен по фактам</h2><small>Хозяева: ${w.sample.home} игр; гости: ${w.sample.away} игр. Факторы: ${(w.factors || []).map(escapeHtml).join(' · ')}. Это оценка модели, не гарантия результата.</small></section>`;
      renderCalculatedMarkets(w); return;
    }
    throw new Error('Нужна история матча');
  } catch (error) { holder.innerHTML = `<div class="analysis-loading">Данные для индивидуального расчёта пока недоступны: ${escapeHtml(error.message || 'ошибка источника')}.</div>`; }
}
function openMatch(id) { selected = fixtures.find(m => m.id === id) || fixtures[0]; renderSelected(); renderList(); renderDetail(); activate('match-detail'); }
function renderAll() { renderSelected(); renderList(); renderSignals(); renderDashboard(); renderPerformance(); renderDetail(); }
async function loadFixtures() {
  // A background forecast must never drive the screen.  In particular, do not
  // start another calendar request while the previous one is still pending.
  if (fixturesLoading) return;
  fixturesLoading = true;
  document.getElementById('last-update').textContent = 'Обновляем календарь…';
  try {
    const response = await fetch('/api/fixtures', { cache: 'no-store' }); const data = await response.json();
    if (!response.ok || !data.fixtures?.length) throw new Error(data.help || data.error || 'Источник не вернул матчи.');
    const selectedId = selected?.id;
    const previousById = new Map(fixtures.map(match => [match.id, match]));
    fixtures = data.fixtures.map(item => {
      const previous = previousById.get(item.id);
      const hasFreshRecommendation = Boolean(item.top_market || item.recommendation_options?.length);
      const hasVisibleRecommendation = Boolean(previous?.top_market || previous?.recommendation_options?.length);
      // A calendar update is allowed to change kick-off time, score and match
      // status immediately.  It is not allowed to blank a recommendation that
      // is already on screen merely because its replacement is still running.
      // Retain the previous value only during a genuine in-progress refresh.
      // A completed "no team data" result, or a match that has gone live,
      // deliberately removes the old pre-match recommendation.
      const isTransientRefresh = ['pending', 'available_on_open'].includes(item.calculation_status);
      if (!hasFreshRecommendation && hasVisibleRecommendation && isTransientRefresh) return {
        ...item,
        top_market: previous.top_market,
        calculation_coverage: previous.calculation_coverage,
        calculation_status: previous.calculation_status,
        calculation_summary: previous.calculation_summary,
        recommendation_options: previous.recommendation_options
      };
      return { ...item, id: item.id, demo: false };
    });
    const current = activeFixtures();
    // Keep the match the user is viewing.  Only choose the first match on the
    // initial load or when the previously selected fixture no longer exists.
    selected = (selectedId && fixtures.find(match => match.id === selectedId))
      || [...current].sort((a, b) => importance(b) - importance(a) || Number(isLive(b)) - Number(isLive(a)) || new Date(a.kickoff) - new Date(b.kickoff))[0]
      || null;
    document.getElementById('source-status').textContent = 'API-FOOTBALL: ПОДКЛЮЧЕНО'; document.getElementById('data-state').textContent = 'LIVE'; document.getElementById('data-state-note').textContent = 'календарь и статусы получены из API'; document.getElementById('fixtures-source').textContent = `${current.length} АКТИВНЫХ МАТЧЕЙ · API-FOOTBALL`;
    document.getElementById('last-update').textContent = `Обновлено: ${new Intl.DateTimeFormat('ru-RU', { hour: '2-digit', minute: '2-digit' }).format(new Date())}`;
    renderAll();
  } catch (error) {
    // Preserve the last complete screen during a temporary source failure.
    // Removing all fixtures here made recommendations visibly flash away every
    // time an upstream request was rate-limited or briefly unavailable.
    if (fixtures.length) {
      document.getElementById('source-status').textContent = 'ИСТОЧНИК: ВРЕМЕННО НЕДОСТУПЕН';
      document.getElementById('data-state').textContent = 'ПОКАЗАНЫ ПОСЛЕДНИЕ ДАННЫЕ';
      document.getElementById('data-state-note').textContent = `Последнее обновление не удалось: ${error.message}`;
      document.getElementById('fixtures-source').textContent = `${activeFixtures().length} АКТИВНЫХ МАТЧЕЙ · ПОСЛЕДНИЕ ДАННЫЕ`;
      document.getElementById('last-update').textContent = 'Обновление источника не удалось — показана последняя готовая версия';
      renderAll();
      return;
    }
    fixtures = []; selected = null;
    document.getElementById('source-status').textContent = 'ИСТОЧНИК: НЕДОСТУПЕН';
    document.getElementById('data-state').textContent = 'НЕТ ДАННЫХ';
    document.getElementById('data-state-note').textContent = error.message;
    document.getElementById('fixtures-source').textContent = 'КАЛЕНДАРЬ НЕДОСТУПЕН';
    document.getElementById('last-update').textContent = `Обновление не удалось: ${error.message}`;
    renderAll();
    return;
  } finally {
    fixturesLoading = false;
  }
}
document.addEventListener('click', event => { const page = event.target.closest('[data-page]'); if (page) return activate(page.dataset.page); const signal = event.target.closest('[data-signal-market]'); if (signal) { signalMarket = signal.dataset.signalMarket; return renderSignals(); } const match = event.target.closest('[data-open]'); if (match) openMatch(match.dataset.open); });
document.querySelector('.menu-button').addEventListener('click', () => document.querySelector('.sidebar').classList.toggle('open'));
['refresh', 'refresh-list'].forEach(id => document.getElementById(id).addEventListener('click', loadFixtures));
document.getElementById('live-filter').addEventListener('click', () => { liveOnly = !liveOnly; document.getElementById('live-filter').textContent = liveOnly ? 'Показать все матчи' : 'Только LIVE'; renderList(); });
document.getElementById('match-search-input').addEventListener('input', event => { matchSearch = event.target.value; document.getElementById('clear-match-search').hidden = !matchSearch; renderList(); });
document.getElementById('clear-match-search').addEventListener('click', () => { matchSearch = ''; const input = document.getElementById('match-search-input'); input.value = ''; document.getElementById('clear-match-search').hidden = true; input.focus(); renderList(); });
renderAll(); loadFixtures();
// Keep live scores and stale scheduled matches current without asking the user
// to press F5. The server itself refreshes the upstream source at most once
// per 45 seconds and falls back to the saved factual calendar on an outage.
setInterval(loadFixtures, 60 * 1000);
