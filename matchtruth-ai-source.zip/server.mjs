/*
 * Local MatchTruth gateway.
 * Deliberately uses only the Node.js standard library: the first live calendar
 * should start without Python, npm install, or any global package.
 */
import { createServer } from 'node:http';
import { setDefaultResultOrder } from 'node:dns';
import { readFile, mkdir, writeFile, stat } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { join, extname, resolve } from 'node:path';
import { createSnapshotStore } from './lib/snapshot-store.mjs';
import { analyseGoals } from './lib/goal-engine.mjs';
import { analyseMatch } from './lib/match-analysis.mjs';
import { createWarehouse } from './lib/warehouse.mjs';
import { predictFromWarehouse } from './lib/warehouse-predictor.mjs';
import { importFootballHistory } from './lib/football-history-import.mjs';
import { modelCompetitionType, modelDataPolicy, selectModelMatches } from './lib/data-policy.mjs';
import { buildModelStatistics } from './lib/model-statistics.mjs';
import { predictMatch } from './lib/universal-prediction-engine.mjs';
import { createLiveDataAcquisitionService, createMemoryCacheProvider, createPrimarySportsDataProvider, createSecondarySportsDataProvider, createInternetResearchProvider } from './lib/live-data-acquisition-service.mjs';
import { createApiFootballClient } from './lib/api-football-client.mjs';

// Some Windows networks publish an IPv6 DNS record but do not permit an IPv6
// HTTPS route.  Prefer IPv4 before making any API-Football request; this does
// not change the provider, key, or factual data returned by it.
setDefaultResultOrder('ipv4first');

const root = resolve(import.meta.dirname);
const cacheDirectory = join(root, 'data', 'raw');
const envPath = join(root, 'backend', '.env');
// One fixed local endpoint for the only supported MatchTruth runtime.
const port = Number(process.env.PORT ?? 8120);
const cacheTtlMs = 6 * 60 * 60 * 1000;
const historyTtlMs = 24 * 60 * 60 * 1000;
// Scores and minute must be fresh enough for a live screen, while the saved
// calendar remains a safe fallback when the external provider is unavailable.
const liveSnapshotTtlMs = 45 * 1000;
const snapshots = createSnapshotStore(cacheDirectory);
const warehouse = createWarehouse(root);
// Calendar rendering must never wait for hundreds of expensive model runs.
// A match gets its complete calculation on opening; completed calculations are
// retained here so subsequent calendar refreshes can show the same top signal.
const predictionCache = new Map();
const forecastWarmups = new Map();
// The calendar refreshes independently from the calculator.  Keep the last
// complete result for each fixture so a refresh can never make an already
// visible recommendation disappear while the next calculation is warming up.
const publishedForecasts = new Map();
const onDemandCache = createMemoryCacheProvider();
const archivedResultSignatures = new Set();
let providerHistoryHydration = { status: 'idle', groups: 0, imported: 0, skipped: 0, error: null, updated_at: null };
let coreHistoryImport = { status: 'idle', groups: 0, imported: 0, skipped: 0, error: null, updated_at: null };
let eventHistoryHydration = { status: 'idle', checked: 0, enriched: 0, skipped: 0, error: null, updated_at: null };
const EVENT_HISTORY_BATCH_SIZE = 30;
let modelStatisticsCache = { warehouse_updated_at: null, generated_at: 0, value: null };

// Core factual archive for the model. IDs are API-Football competition IDs;
// no odds, ready-made predictions, or bookmaker values are imported.
const CORE_HISTORY_COMPETITIONS = [
  { id: 5, name: 'UEFA Nations League', seasons: [2026, 2025, 2024, 2023, 2022] },
  { id: 4, name: 'UEFA Euro', seasons: [2024, 2020] },
  { id: 1, name: 'FIFA World Cup', seasons: [2026, 2022] },
  { id: 9, name: 'Copa America', seasons: [2024, 2021] },
  { id: 39, name: 'England Premier League', seasons: [2026, 2025, 2024, 2023, 2022] },
  { id: 140, name: 'Spain La Liga', seasons: [2026, 2025, 2024, 2023, 2022] },
  { id: 78, name: 'Germany Bundesliga', seasons: [2026, 2025, 2024, 2023, 2022] },
  { id: 135, name: 'Italy Serie A', seasons: [2026, 2025, 2024, 2023, 2022] },
  { id: 61, name: 'France Ligue 1', seasons: [2026, 2025, 2024, 2023, 2022] }
];

function recommendationOptions(prediction) {
  if (!prediction?.probabilities) return [];
  const goal = prediction.probabilities;
  const item = (market, label, probability) => ({ market, label, probability: Number(probability) });
  return [
    item('Исход', 'Победа хозяев', goal.home_win), item('Исход', 'Ничья', goal.draw), item('Исход', 'Победа гостей', goal.away_win),
    item('Голы', 'ТБ 1.5', goal.over_1_5), item('Голы', 'ТМ 1.5', goal.under_1_5), item('Голы', 'ТБ 2.5', goal.over_2_5), item('Голы', 'ТМ 2.5', goal.under_2_5), item('Голы', 'Обе забьют — да', goal.btts_yes), item('Голы', 'Обе забьют — нет', goal.btts_no)
    // Event markets are intentionally excluded here. The calendar warm-up
    // uses the legacy local warehouse, which may not contain the factual
    // API-Football event history for both exact teams. Corners/cards are only
    // shown after an on-demand factual analysis of the selected fixture.
  ].filter(option => Number.isFinite(option.probability));
}

function isFinishedFixture(status) { return ['FT', 'AET', 'PEN', 'AWD', 'WO'].includes(status); }
function isLiveFixture(status) { return ['1H', 'HT', '2H', 'ET', 'BT', 'P', 'LIVE', 'INP'].includes(status); }
function shouldWarmForecast(fixture, now = Date.now()) {
  if (isFinishedFixture(fixture.status) || isLiveFixture(fixture.status) || ['PST', 'CANC', 'ABD', 'SUSP'].includes(fixture.status)) return false;
  const kickoff = new Date(fixture.kickoff).getTime();
  // Match the calendar's active-window rule. Forecasting old results and
  // postponed fixtures wastes CPU and can delay the first visible calendar.
  return !Number.isFinite(kickoff) || kickoff > now - 2 * 60 * 60 * 1000;
}
async function archiveFinishedFixtures(fixtures) {
  const facts = fixtures.filter(fixture => isFinishedFixture(fixture.status) && Number.isFinite(fixture.home_goals) && Number.isFinite(fixture.away_goals))
    .map(fixture => ({
      id: `api-football-result:${fixture.provider_fixture_id}`,
      provider: 'api-football', provider_fixture_id: fixture.provider_fixture_id,
      date: String(fixture.kickoff || '').slice(0, 10), competition: fixture.league, country: fixture.country, season: fixture.season,
      home_team: fixture.home, away_team: fixture.away, home_goals: fixture.home_goals, away_goals: fixture.away_goals,
      source_quality: 'api-football-factual-result', source_url: 'https://www.api-football.com/'
    })).filter(fact => fact.date && fact.home_team && fact.away_team);
  const newFacts = facts.filter(fact => {
    const signature = `${fact.id}:${fact.home_goals}:${fact.away_goals}`;
    if (archivedResultSignatures.has(signature)) return false;
    archivedResultSignatures.add(signature); return true;
  });
  if (newFacts.length) await warehouse.upsert(newFacts);
}

function warmForecasts(version, modelMatches, warehouseUpdatedAt, fixtures) {
  const existing = forecastWarmups.get(version);
  if (existing) return existing;
  const state = { status: 'running', total: fixtures.length, ready: 0 };
  forecastWarmups.set(version, state);
  let cursor = 0;
  const nextBatch = () => {
    // Yield often: live calendar and a clicked match must stay responsive while
    // MatchTruth prepares all of today's individual calculations.
    const batchEnd = Math.min(cursor + 6, fixtures.length);
    for (; cursor < batchEnd; cursor += 1) {
      const fixture = fixtures[cursor];
      const predictionKey = `${warehouseUpdatedAt || 'warehouse'}:${fixture.provider_fixture_id}`;
      if (!predictionCache.has(predictionKey)) {
        predictionCache.set(predictionKey, predictFromWarehouse({ matches: modelMatches, homeTeam: fixture.home, awayTeam: fixture.away, country: fixture.country, league: fixture.league }));
      }
      state.ready += 1;
    }
    if (cursor < fixtures.length) setImmediate(nextBatch);
    else state.status = 'complete';
  };
  setImmediate(nextBatch);
  return state;
}
let historyImport = { status: 'not_started', result: null, error: null };
function startHistoryImport() {
  if (historyImport.status === 'running' || historyImport.status === 'complete') return;
  historyImport = { status: 'running', result: null, error: null };
  importFootballHistory(warehouse, event => console.log(`History import ${event.seasonCode}/${event.code}: ${event.error || event.imported}`))
    .then(result => { historyImport = { status: 'complete', result, error: null }; console.log(`History import complete: ${result.added} matches.`); })
    .catch(error => { historyImport = { status: 'failed', result: null, error: error.message }; console.error('History import failed:', error.message); });
}
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8' };

function parseEnv(text) {
  return Object.fromEntries(text.split(/\r?\n/).map(line => line.trim()).filter(line => line && !line.startsWith('#')).map(line => {
    const pos = line.indexOf('='); return [line.slice(0, pos), line.slice(pos + 1)];
  }));
}
async function apiKey() {
  let fileEnv = {};
  try { fileEnv = parseEnv(await readFile(envPath, 'utf8')); } catch { /* Render uses environment variables, not a local .env file. */ }
  const key = (process.env.API_FOOTBALL_KEY || fileEnv.API_FOOTBALL_KEY || '').trim();
  if (!key || key === 'PASTE_YOUR_FREE_API_FOOTBALL_KEY_HERE') throw new Error('API_KEY_NOT_CONFIGURED');
  return key;
}
const apiFootball = createApiFootballClient({ getApiKey: apiKey });
async function upstream(path, options) { return apiFootball.json(path, options); }

function providerHelp(error) {
  const diagnosticText = JSON.stringify(error?.diagnostic?.errors || '').toLowerCase();
  if (error?.message === 'API_FOOTBALL_KEY_NOT_CONFIGURED' || diagnosticText.includes('api_key_not_configured')) {
    return 'В Render не задан API_FOOTBALL_KEY. Откройте сервис matchtruth-ai → Environment, добавьте API_FOOTBALL_KEY как Secret и redeploy.';
  }
  if (diagnosticText.includes('missing application key')) {
    return 'API-Football не получил действительный ключ. Проверьте значение API_FOOTBALL_KEY в Render → Environment и сохраните правильный ключ API-Football.';
  }
  if (error?.kind === 'authentication_key_error' || error?.message === 'API_FOOTBALL_AUTHENTICATION_ERROR_403') {
    return 'API-Football отклонил ключ. Проверьте, что API_FOOTBALL_KEY в Render содержит активный ключ API-Football без пробелов.';
  }
  if (error?.message === 'API_FOOTBALL_NETWORK_ERROR' || error?.message === 'API_FOOTBALL_TIMEOUT') {
    return 'Ключ API-Football сохранён. Сервер не может установить HTTPS-соединение с v3.football.api-sports.io (сетевой доступ временно заблокирован). Повторите обновление позже: данные не подменяются демонстрационными.';
  }
  if (error?.message === 'API_KEY_NOT_CONFIGURED') return 'Ключ API-Football не задан. Для локального запуска добавьте его в backend/.env; для Render задайте API_FOOTBALL_KEY в настройках Environment.';
  return 'Не удалось получить фактический календарь API-Football. Демонстрационные матчи не используются.';
}
async function fixturesForToday() {
  const date = new Date().toISOString().slice(0, 10);
  // v2 adds live status and score fields; do not reuse the former incomplete snapshot.
  const cacheKey = `api-football-fixtures-v2-${date}`;
  // A saved same-day calendar is authoritative when the remote provider is
  // slow or temporarily unreachable. Never discard 813 factual fixtures and
  // fall back to the two-match UI demo merely because refresh timed out.
  const cached = await snapshots.get(cacheKey, 36 * 60 * 60 * 1000);
  const cachedCalendar = cached ? { ...cached, fixtures: cached.fixtures.map(fixture => ({ ...fixture, data_provider: fixture.data_provider || 'API-Football' })) } : null;
  const cachedAt = cached?.stored_at ? new Date(cached.stored_at).getTime() : 0;
  if (cachedCalendar && Number.isFinite(cachedAt) && Date.now() - cachedAt < liveSnapshotTtlMs) return cachedCalendar;
  let body;
  try { body = await upstream(`/fixtures?date=${date}&timezone=Europe%2FBratislava`); }
  catch (error) {
    // Never remove real fixtures or a last known score just because the
    // provider is slow.  The UI marks the saved timestamp as its source.
    if (cachedCalendar) return { ...cachedCalendar, source: 'api-football-cache', refresh_error: error.message };
    throw error;
  }
  const fixtures = body.response.map(item => ({
    id: `api-football:${item.fixture.id}`, provider_fixture_id: item.fixture.id, kickoff: item.fixture.date,
    status: item.fixture.status.short, status_long: item.fixture.status.long, elapsed: item.fixture.status.elapsed,
    home: item.teams.home.name, away: item.teams.away.name,
    home_goals: item.goals?.home, away_goals: item.goals?.away,
    home_team_id: item.teams.home.id, away_team_id: item.teams.away.id,
    league: item.league.name, country: item.league.country, round: item.league.round,
    league_id: item.league.id, season: item.league.season,
    data_provider: 'API-Football', data_status: 'fixtures_loaded', analysis_status: 'pending_history_collection'
  }));
  const snapshot = { source: 'api-football', received_at: new Date().toISOString(), fixtures };
  await snapshots.put(cacheKey, snapshot);
  archiveFinishedFixtures(fixtures).catch(error => console.error('Result archive failed:', error.message));
  return snapshot;
}
async function apiJson(path) {
  return (await upstream(path)).response;
}
function requestDate(value) { return String(value || '').slice(0, 10); }
async function onDemandPrediction(request) {
  const localHistory = await warehouse.read();
  const service = createLiveDataAcquisitionService({
    cache: onDemandCache,
    primary: createPrimarySportsDataProvider({ apiJson }),
    secondary: createSecondarySportsDataProvider(),
    internetResearch: createInternetResearchProvider(),
    localCacheMatches: selectModelMatches(localHistory.matches)
  });
  const acquisition = await service.acquire(request);
  if (!acquisition.fixture) return { status: acquisition.status, match: null, acquisition };
  const prediction = predictMatch({ fixture: acquisition.fixture, warehouseMatches: acquisition.matches, collectedAt: new Date().toISOString() });
  return { ...prediction, acquisition: { ...acquisition.acquisition, facts: acquisition.facts } };
}
async function readJsonBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const raw = Buffer.concat(chunks).toString('utf8');
  if (!raw) return {};
  try { return JSON.parse(raw); } catch { throw new Error('INVALID_JSON_BODY'); }
}
async function leagueSeasonFixtures(leagueId, season) {
  const key = `api-football-league-${leagueId}-season-${season}`;
  const cached = await snapshots.get(key, historyTtlMs);
  if (cached) return cached.fixtures;
  const fixtures = await apiJson(`/fixtures?league=${encodeURIComponent(leagueId)}&season=${encodeURIComponent(season)}`);
  await snapshots.put(key, { fixtures });
  return fixtures;
}
function factFromProviderFixture(item) {
  if (!item?.fixture?.id || !isFinishedFixture(item.fixture.status?.short)) return null;
  const homeGoals = item.goals?.home, awayGoals = item.goals?.away;
  if (!Number.isFinite(homeGoals) || !Number.isFinite(awayGoals)) return null;
  return {
    id: `api-football-history:${item.fixture.id}`,
    provider: 'api-football', provider_fixture_id: item.fixture.id,
    date: String(item.fixture.date || '').slice(0, 10),
    competition: item.league?.name || '', country: item.league?.country || '', season: item.league?.season,
    home_team: item.teams?.home?.name || '', away_team: item.teams?.away?.name || '',
    home_goals: homeGoals, away_goals: awayGoals,
    source_quality: 'api-football-completed-fixture', source_url: 'https://www.api-football.com/'
  };
}
function providerHistorySeasons(fixture) {
  const season = Number(fixture.season);
  if (!Number.isFinite(season)) return [];
  // Current season plus two prior seasons: enough to cover the active cycle
  // while the five-year policy remains the final modelling gate.
  return [season, season - 1, season - 2].filter(value => value > 2000);
}
async function hydrateProviderHistory(fixtures) {
  if (providerHistoryHydration.status === 'running') return providerHistoryHydration;
  const groups = new Map();
  for (const fixture of fixtures) {
    if (!fixture.league_id || !fixture.season || !modelCompetitionType({ competition: fixture.league })) continue;
    groups.set(`${fixture.league_id}:${fixture.season}`, fixture);
  }
  if (!groups.size) return providerHistoryHydration;
  providerHistoryHydration = { status: 'running', groups: groups.size, imported: 0, skipped: 0, error: null, updated_at: new Date().toISOString() };
  const facts = [];
  try {
    for (const fixture of groups.values()) {
      for (const season of providerHistorySeasons(fixture)) {
        try {
          const rows = await leagueSeasonFixtures(fixture.league_id, season);
          facts.push(...rows.map(factFromProviderFixture).filter(Boolean));
        } catch (error) {
          providerHistoryHydration.skipped += 1;
          console.error(`Provider history ${fixture.league_id}/${season} failed:`, error.message);
        }
      }
    }
    const unique = [...new Map(facts.map(fact => [fact.id, fact])).values()];
    if (unique.length) {
      await warehouse.upsert(unique);
      predictionCache.clear();
      forecastWarmups.clear();
    }
    providerHistoryHydration = { ...providerHistoryHydration, status: 'complete', imported: unique.length, updated_at: new Date().toISOString() };
  } catch (error) {
    providerHistoryHydration = { ...providerHistoryHydration, status: 'failed', error: error.message, updated_at: new Date().toISOString() };
  }
  return providerHistoryHydration;
}
async function importCoreProviderHistory() {
  if (coreHistoryImport.status === 'running' || coreHistoryImport.status === 'complete') return coreHistoryImport;
  const requestedGroups = CORE_HISTORY_COMPETITIONS.flatMap(competition => competition.seasons.map(season => ({ ...competition, season })));
  coreHistoryImport = { status: 'running', groups: requestedGroups.length, imported: 0, skipped: 0, error: null, updated_at: new Date().toISOString() };
  const facts = [];
  try {
    for (const group of requestedGroups) {
      try {
        const rows = await leagueSeasonFixtures(group.id, group.season);
        const completed = rows.map(factFromProviderFixture).filter(Boolean);
        facts.push(...completed);
        console.log(`Core history ${group.name}/${group.season}: ${completed.length} completed facts.`);
      } catch (error) {
        coreHistoryImport.skipped += 1;
        console.error(`Core history ${group.name}/${group.season} failed:`, error.message);
      }
    }
    const unique = [...new Map(facts.map(fact => [fact.id, fact])).values()];
    if (unique.length) {
      await warehouse.upsert(unique);
      predictionCache.clear();
      forecastWarmups.clear();
    }
    coreHistoryImport = { ...coreHistoryImport, status: 'complete', imported: unique.length, updated_at: new Date().toISOString() };
  } catch (error) {
    coreHistoryImport = { ...coreHistoryImport, status: 'failed', error: error.message, updated_at: new Date().toISOString() };
  }
  return coreHistoryImport;
}
function numericStatistic(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  const parsed = Number.parseFloat(String(value ?? '').replace('%', ''));
  return Number.isFinite(parsed) ? parsed : 0;
}
function statisticsForTeam(row) {
  const values = new Map((row?.statistics || []).map(stat => [String(stat.type || '').toLowerCase(), numericStatistic(stat.value)]));
  const corners = values.get('corner kicks');
  const yellow = values.get('yellow cards') || 0;
  const red = values.get('red cards') || 0;
  return { corners: Number.isFinite(corners) ? corners : null, cards: yellow + red };
}
async function hydrateEventHistory(fixtures) {
  if (eventHistoryHydration.status === 'running') return eventHistoryHydration;
  const activeTeams = new Set(fixtures
    .filter(fixture => modelCompetitionType({ competition: fixture.league, country: fixture.country }))
    .flatMap(fixture => [fixture.home, fixture.away]));
  if (!activeTeams.size) return eventHistoryHydration;
  const local = await warehouse.read();
  const candidates = local.matches
    .filter(fact => fact.provider === 'api-football' && fact.provider_fixture_id && !fact.event_stats_checked_at)
    .filter(fact => activeTeams.has(fact.home_team) || activeTeams.has(fact.away_team))
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, EVENT_HISTORY_BATCH_SIZE);
  if (!candidates.length) return { ...eventHistoryHydration, status: 'complete' };
  eventHistoryHydration = { status: 'running', checked: 0, enriched: 0, skipped: 0, error: null, updated_at: new Date().toISOString() };
  const updates = [];
  try {
    for (const fact of candidates) {
      try {
        const rows = await apiJson(`/fixtures/statistics?fixture=${encodeURIComponent(fact.provider_fixture_id)}`);
        const byName = new Map(rows.map(row => [row.team?.name, row]));
        const home = statisticsForTeam(byName.get(fact.home_team) || rows[0]);
        const away = statisticsForTeam(byName.get(fact.away_team) || rows[1]);
        const hasCorners = Number.isFinite(home.corners) && Number.isFinite(away.corners);
        const hasCards = rows.length >= 2;
        updates.push({ ...fact, ...(hasCorners ? { home_corners: home.corners, away_corners: away.corners } : {}), ...(hasCards ? { home_cards: home.cards, away_cards: away.cards } : {}), event_stats_checked_at: new Date().toISOString(), event_stats_source: 'api-football-fixture-statistics' });
        eventHistoryHydration.checked += 1;
        if (hasCorners || hasCards) eventHistoryHydration.enriched += 1; else eventHistoryHydration.skipped += 1;
      } catch (error) {
        // Mark an unavailable fixture as checked so ordinary page refreshes do
        // not spend the user's free API quota retrying it forever.
        updates.push({ ...fact, event_stats_checked_at: new Date().toISOString(), event_stats_source: `unavailable:${error.message}` });
        eventHistoryHydration.checked += 1; eventHistoryHydration.skipped += 1;
      }
    }
    if (updates.length) {
      await warehouse.upsert(updates);
      predictionCache.clear(); forecastWarmups.clear();
    }
    eventHistoryHydration = { ...eventHistoryHydration, status: 'complete', updated_at: new Date().toISOString() };
  } catch (error) {
    eventHistoryHydration = { ...eventHistoryHydration, status: 'failed', error: error.message, updated_at: new Date().toISOString() };
  }
  return eventHistoryHydration;
}
async function historyForTeam(teamId, leagueId, season) {
  if (!leagueId || !season) throw new Error('LEAGUE_SEASON_MISSING');
  // The free plan blocks `last=20`. We therefore build MatchTruth's own
  // historical store from factual league-season fixture lists, newest first.
  const seasons = [Number(season), Number(season) - 1].filter(Number.isFinite);
  const rows = [];
  for (const value of seasons) {
    const fixtures = await leagueSeasonFixtures(leagueId, value);
    rows.push(...fixtures.filter(item => item.fixture?.status?.short === 'FT' && (item.teams?.home?.id === teamId || item.teams?.away?.id === teamId)));
    if (rows.length >= 20) break;
  }
  const unique = [...new Map(rows.map(item => [item.fixture.id, item])).values()];
  return unique.sort((a, b) => new Date(a.fixture.date) - new Date(b.fixture.date)).slice(-20);
}
async function analysisForFixture(providerId) {
  const calendar = await fixturesForToday(); const fixture = calendar.fixtures.find(item => String(item.provider_fixture_id) === String(providerId));
  if (!fixture) throw new Error('FIXTURE_NOT_IN_TODAY_CALENDAR');
  // Do not hydrate a whole competition here. The on-demand acquisition path
  // below requests only the two teams for this selected fixture.
  const localHistory = await warehouse.read();
  const modelMatches = selectModelMatches(localHistory.matches);
  let universal_prediction;
  try {
    universal_prediction = await onDemandPrediction({ homeTeam: fixture.home, awayTeam: fixture.away, date: requestDate(fixture.kickoff), competition: fixture.league });
  } catch (error) {
    // The selected match remains analyzable from already cached facts if a
    // live provider is temporarily rate-limited.  This is a fallback, never a
    // requirement that the match existed in the local warehouse first.
    universal_prediction = { ...predictMatch({ fixture, warehouseMatches: modelMatches, collectedAt: new Date().toISOString() }), acquisition: { source: 'local-cache-fallback', error: error.message } };
  }
  const predictionKey = `${localHistory.updated_at || 'warehouse'}:${fixture.provider_fixture_id}`;
  let warehouse_prediction = predictionCache.get(predictionKey);
  if (!warehouse_prediction) {
    warehouse_prediction = predictFromWarehouse({ matches: modelMatches, homeTeam: fixture.home, awayTeam: fixture.away, country: fixture.country, league: fixture.league });
    predictionCache.set(predictionKey, warehouse_prediction);
  }
  // The legacy analysis used to issue two more league-season requests after
  // the on-demand team history was already acquired. Do not spend quota twice
  // for the same analysis. The screen uses universal_prediction above.
  return { fixture_id: providerId, collected_at: new Date().toISOString(), analysis: null, warehouse_prediction, universal_prediction, provider_history_status: 'not_requested: legacy duplicate provider calls disabled' };
}
async function modelStatistics() {
  const localHistory = await warehouse.read();
  const fresh = modelStatisticsCache.value
    && modelStatisticsCache.warehouse_updated_at === localHistory.updated_at
    && Date.now() - modelStatisticsCache.generated_at < 5 * 60 * 1000;
  if (fresh) return modelStatisticsCache.value;
  const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
  const value = {
    current_note: 'Ретропроверка строится только по фактам, известным до начала каждого исторического матча. Это не архив заранее сохранённых прогнозов.',
    recent: buildModelStatistics(localHistory.matches, { limit: 60 }),
    yesterday: buildModelStatistics(localHistory.matches, { limit: 40, day: yesterday })
  };
  modelStatisticsCache = { warehouse_updated_at: localHistory.updated_at, generated_at: Date.now(), value };
  return value;
}
function sendJson(res, statusCode, body) { res.writeHead(statusCode, { 'content-type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(body)); }
async function sendStatic(res, requestPath) {
  const safePath = requestPath === '/' ? 'index.html' : requestPath.replace(/^\/+/, '');
  const filename = resolve(root, safePath);
  if (!filename.startsWith(root)) return sendJson(res, 403, { error: 'Forbidden' });
  try {
    await stat(filename);
    // This is a local development app.  Never make the user fight a stale
    // JavaScript/CSS cache after an update: ordinary browser refresh is enough.
    res.writeHead(200, { 'content-type': mime[extname(filename)] || 'application/octet-stream', 'cache-control': 'no-store' });
    createReadStream(filename).pipe(res);
  }
  catch { sendJson(res, 404, { error: 'File not found' }); }
}
createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (url.pathname === '/api/prediction-request' && req.method === 'POST') {
    try {
      const input = await readJsonBody(req);
      const request = { homeTeam: input.homeTeam, awayTeam: input.awayTeam, date: requestDate(input.date), competition: input.competition || null };
      if (!request.homeTeam || !request.awayTeam || !request.date) return sendJson(res, 400, { error: 'homeTeam, awayTeam and date are required.' });
      return sendJson(res, 200, await onDemandPrediction(request));
    } catch (error) { return sendJson(res, 503, { error: error.message, help: 'Live data acquisition could not resolve or acquire this fixture.' }); }
  }
  if (url.pathname === '/api/health') {
    let configuredKey = true;
    try { await apiKey(); } catch { configuredKey = false; }
    return sendJson(res, 200, { status: 'ok', engine: 'matchtruth-node-gateway', api_football_key_configured: configuredKey, history_import: historyImport, core_history_import: coreHistoryImport, event_history_hydration: eventHistoryHydration });
  }
  if (url.pathname === '/api/api-football-status') {
    try { return sendJson(res, 200, await apiFootball.status()); }
    catch (error) { return sendJson(res, 503, { error: error.message, kind: error.kind || 'internal_application_error', diagnostic: error.diagnostic || null, local_diagnostics: apiFootball.report() }); }
  }
  if (url.pathname === '/api/history-import') { startHistoryImport(); return sendJson(res, 202, { history_import: historyImport }); }
  if (url.pathname === '/api/core-history-import') {
    importCoreProviderHistory().catch(error => console.error('Core provider history import failed:', error.message));
    return sendJson(res, 202, { core_history_import: coreHistoryImport });
  }
  if (url.pathname === '/api/model-statistics') {
    try { return sendJson(res, 200, await modelStatistics()); }
    catch (error) { return sendJson(res, 503, { error: error.message }); }
  }
  if (url.pathname === '/api/fixtures') {
    try {
      const calendar = await fixturesForToday();
      // Calendar loading must not fan out into hundreds of provider calls.
      // Detailed facts are acquired only for the match the user requests.
      const localHistory = await warehouse.read();
      const modelMatches = selectModelMatches(localHistory.matches);
      // Calendar snapshots receive a new timestamp whenever the source is
      // refreshed.  That timestamp must not restart the same day's warm-up,
      // otherwise recommendations flicker between ready and pending.
      const version = `${localHistory.updated_at || 'warehouse'}:${new Date().toISOString().slice(0, 10)}`;
      const warmableFixtures = calendar.fixtures.filter(fixture => shouldWarmForecast(fixture));
      const calculation_progress = warmForecasts(version, modelMatches, localHistory.updated_at, warmableFixtures);
      const fixtures = calendar.fixtures.map(fixture => {
        const predictionKey = `${localHistory.updated_at || 'warehouse'}:${fixture.provider_fixture_id}`;
        const freshCalculation = predictionCache.get(predictionKey);
        if (freshCalculation?.probabilities) publishedForecasts.set(String(fixture.provider_fixture_id), freshCalculation);
        const calculation = freshCalculation?.probabilities
          ? freshCalculation
          : publishedForecasts.get(String(fixture.provider_fixture_id));
        // A competition average is not a calculation for this pair.  Do not
        // turn it into a high-confidence recommendation merely because the
        // formula returns a large percentage.  If team evidence is missing,
        // the UI must say so instead of publishing a generic league prior.
        // The same rule applies once a match is live: a pre-match estimate is
        // no longer current without a separate live-statistics model.
        const teamHistoryCalculation = calculation?.coverage === 'team_history_available';
        const hasCalculatedMarkets = teamHistoryCalculation && !isLiveFixture(fixture.status);
        return {
          ...fixture,
          top_market: hasCalculatedMarkets ? calculation.strongest_market : null,
          calculation_coverage: calculation?.coverage ?? 'available_on_open',
          calculation_status: calculation?.status ?? 'pending',
          calculation_summary: hasCalculatedMarkets ? {
            sample_home: calculation.sample?.home ?? 0,
            sample_away: calculation.sample?.away ?? 0,
            outcome_and_goals: Boolean(calculation.probabilities),
            corners: Boolean(calculation.corners?.probabilities),
            cards: Boolean(calculation.cards?.probabilities),
            evidence: teamHistoryCalculation ? 'team_history' : 'competition_profile'
          } : null,
          recommendation_options: hasCalculatedMarkets ? recommendationOptions(calculation) : []
        };
      });
      return sendJson(res, 200, { ...calendar, fixtures, calculation_progress, provider_history_hydration: providerHistoryHydration, event_history_hydration: eventHistoryHydration, model_data: { raw_matches: localHistory.matches.length, eligible_matches: modelMatches.length, policy: modelDataPolicy() } });
    }
    catch (error) { return sendJson(res, 503, { error: error.message, help: providerHelp(error), provider_diagnostic: error.diagnostic || null }); }
  }
  if (url.pathname.startsWith('/api/analysis/')) {
    try { return sendJson(res, 200, await analysisForFixture(url.pathname.split('/').pop())); }
    catch (error) { return sendJson(res, 503, { error: error.message, help: 'Analysis needs a working API connection and sufficient completed factual matches.' }); }
  }
  if (url.pathname.startsWith('/api/prediction/')) {
    try {
      const result = await analysisForFixture(url.pathname.split('/').pop());
      return sendJson(res, 200, result.universal_prediction);
    }
    catch (error) { return sendJson(res, 503, { error: error.message, help: 'Prediction needs a factual fixture and stored match history.' }); }
  }
  return sendStatic(res, url.pathname);
}).listen(port, '0.0.0.0', () => {
  console.log(`MatchTruth AI: http://127.0.0.1:${port}/`);
  // Keep startup focused on serving the live calendar. Historical imports can
  // consume thousands of API-Football requests, so they remain explicitly
  // available through /api/history-import instead of running on every deploy.
});
