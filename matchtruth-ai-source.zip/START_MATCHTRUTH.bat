@echo off
setlocal
title MatchTruth AI — Local Server
cd /d "%~dp0"
set "PORT=8120"
echo.
echo MatchTruth AI is running at: http://127.0.0.1:8120/
echo Keep this window open while using MatchTruth.
echo This window automatically reloads the server after updates.
echo.
"C:\Program Files\nodejs\node.exe" --watch server.mjs
echo.
echo MatchTruth stopped. Read data\matchtruth-server.log if a log was created.
pause
endlocal
