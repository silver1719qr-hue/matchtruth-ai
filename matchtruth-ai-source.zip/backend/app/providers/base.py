from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date
from typing import Any


class FootballProvider(ABC):
    """Small stable boundary between MatchTruth and any external data supplier."""

    name: str

    @abstractmethod
    async def fixtures_by_date(self, target_date: date) -> list[dict[str, Any]]:
        """Return normalized factual fixtures only; never provider predictions."""
        raise NotImplementedError
