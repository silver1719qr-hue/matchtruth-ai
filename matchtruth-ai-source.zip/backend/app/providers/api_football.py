from __future__ import annotations

from datetime import date
from typing import Any

import httpx

from .base import FootballProvider


class ApiFootballProvider(FootballProvider):
    """Adapter for API-Football v3; fetches factual fixtures only."""

    name = "api-football"
    base_url = "https://v3.football.api-sports.io"

    def __init__(self, api_key: str) -> None:
        self._api_key = api_key

    async def fixtures_by_date(self, target_date: date) -> list[dict[str, Any]]:
        headers = {"x-apisports-key": self._api_key}
        params = {"date": target_date.isoformat(), "timezone": "Europe/Bratislava"}
        async with httpx.AsyncClient(timeout=25) as client:
            response = await client.get(f"{self.base_url}/fixtures", headers=headers, params=params)
            response.raise_for_status()
            payload: dict[str, Any] = response.json()

        errors = payload.get("errors") or {}
        if errors:
            raise RuntimeError(f"API-Football returned errors: {errors}")

        # Deliberately retain only observed schedule/status metadata for the listing.
        # Statistics, lineups and injuries are loaded later by dedicated collectors.
        normalized: list[dict[str, Any]] = []
        for item in payload.get("response", []):
            fixture = item["fixture"]
            league = item["league"]
            teams = item["teams"]
            normalized.append(
                {
                    "id": f"api-football:{fixture['id']}",
                    "provider_fixture_id": fixture["id"],
                    "kickoff": fixture["date"],
                    "status": fixture["status"]["short"],
                    "home": teams["home"]["name"],
                    "away": teams["away"]["name"],
                    "league": league["name"],
                    "country": league.get("country"),
                    "round": league.get("round"),
                    "league_logo": league.get("logo"),
                    "home_logo": teams["home"].get("logo"),
                    "away_logo": teams["away"].get("logo"),
                    "data_status": "fixtures_loaded",
                    "analysis_status": "pending_history_collection",
                }
            )
        return normalized
