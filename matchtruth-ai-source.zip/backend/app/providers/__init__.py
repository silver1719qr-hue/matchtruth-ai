"""Data-provider adapters. Models never call an external provider directly."""
