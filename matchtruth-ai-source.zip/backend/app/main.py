from __future__ import annotations

import asyncio
import json
import os
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .providers.api_football import ApiFootballProvider

PROJECT_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(PROJECT_ROOT / "backend" / ".env")
RAW_DIR = PROJECT_ROOT / "data" / "raw"
RAW_DIR.mkdir(parents=True, exist_ok=True)
CACHE_TTL_SECONDS = int(os.getenv("FIXTURES_CACHE_TTL_SECONDS", "21600"))

app = FastAPI(title="MatchTruth AI", version="0.1.0")
app.mount("/assets", StaticFiles(directory=PROJECT_ROOT), name="assets")


def _cache_file(target_date: date) -> Path:
    return RAW_DIR / f"api-football-fixtures-{target_date.isoformat()}.json"


def _fresh_snapshot(path: Path) -> bool:
    if not path.exists():
        return False
    age = datetime.now(timezone.utc).timestamp() - path.stat().st_mtime
    return age < CACHE_TTL_SECONDS


async def _fetch_and_snapshot(target_date: date) -> list[dict[str, Any]]:
    api_key = os.getenv("API_FOOTBALL_KEY", "").strip()
    if not api_key or api_key == "replace_with_your_key":
        raise HTTPException(
            status_code=503,
            detail="API_FOOTBALL_KEY is not configured. Add it to the environment; it must never be exposed to the browser.",
        )
    try:
        fixtures = await ApiFootballProvider(api_key).fixtures_by_date(target_date)
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"API-Football HTTP error: {exc.response.status_code}") from exc
    except (httpx.HTTPError, RuntimeError) as exc:
        raise HTTPException(status_code=502, detail="Could not retrieve factual fixtures from API-Football.") from exc

    snapshot: dict[str, Any] = {
        "provider": "api-football",
        "received_at": datetime.now(timezone.utc).isoformat(),
        "target_date": target_date.isoformat(),
        "fixtures": fixtures,
    }
    _cache_file(target_date).write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")
    return fixtures


@app.get("/api/fixtures")
async def fixtures(target_date: date = Query(default_factory=date.today, alias="date")) -> dict[str, Any]:
    """All factual fixtures for a date, cached to protect the free daily quota."""
    cache = _cache_file(target_date)
    if _fresh_snapshot(cache):
        snapshot = json.loads(cache.read_text(encoding="utf-8"))
        return {"source": "api-football-cache", "received_at": snapshot["received_at"], "fixtures": snapshot["fixtures"]}
    loaded = await _fetch_and_snapshot(target_date)
    return {"source": "api-football", "received_at": datetime.now(timezone.utc).isoformat(), "fixtures": loaded}


@app.get("/api/health")
async def health() -> dict[str, Any]:
    return {"status": "ok", "provider": "api-football", "key_configured": bool(os.getenv("API_FOOTBALL_KEY", "").strip())}


@app.get("/")
async def frontend() -> FileResponse:
    return FileResponse(PROJECT_ROOT / "index.html")
