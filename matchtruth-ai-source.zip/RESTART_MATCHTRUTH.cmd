@echo off
setlocal
title MatchTruth AI — Update and Start
cd /d "%~dp0"
set "PORT=8120"

rem Stop only the process that is occupying MatchTruth's dedicated local port.
for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":8120 .*LISTENING"') do taskkill /PID %%P /F >nul 2>&1
timeout /t 1 /nobreak >nul

start "" "http://127.0.0.1:8120/"
echo.
echo MatchTruth AI is starting at http://127.0.0.1:8120/
echo Keep this one window open. The server reloads itself after updates.
echo.
"C:\Program Files\nodejs\node.exe" --watch server.mjs

echo.
echo MatchTruth stopped.
pause
endlocal
