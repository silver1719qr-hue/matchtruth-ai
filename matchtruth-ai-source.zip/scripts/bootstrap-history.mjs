/* Idempotent historical bootstrap for the local MatchTruth fact warehouse. */
import { resolve } from 'node:path';
import { createWarehouse } from '../lib/warehouse.mjs';
import { importStatsBombSeason, extractStatsBombMatchStats } from '../lib/providers/statsbomb-open.mjs';

const root = resolve(import.meta.dirname, '..');
const warehouse = createWarehouse(root);
const publicSeeds = [
  { competitionId: 43, seasonId: 106 }, // FIFA World Cup 2022
  { competitionId: 55, seasonId: 282 }, // UEFA Euro 2024
  { competitionId: 55, seasonId: 43 }   // UEFA Euro 2020
];
let total = 0;
for (const seed of publicSeeds) {
  const facts = await importStatsBombSeason(seed);
  const result = await warehouse.upsert(facts);
  total += result.added_or_updated;
  console.log(`StatsBomb ${seed.competitionId}/${seed.seasonId}: ${result.added_or_updated} matches; warehouse total ${result.total_matches}`);
}
const current = await warehouse.read();
const pending = current.matches.filter(match => match.provider === 'statsbomb-open' && match.home_corners == null);
const parallel = 8;
for (let index = 0; index < pending.length; index += parallel) {
  const batch = pending.slice(index, index + parallel);
  const enriched = await Promise.all(batch.map(async match => {
    const response = await fetch(`https://raw.githubusercontent.com/hudl/open-data/master/data/events/${match.provider_match_id}.json`);
    if (!response.ok) throw new Error(`STATSBOMB_EVENT_HTTP_${response.status}`);
    const events = await response.json();
    return { ...match, ...extractStatsBombMatchStats(events, match.home_team, match.away_team) };
  }));
  await warehouse.upsert(enriched);
  console.log(`StatsBomb events: ${Math.min(index + parallel, pending.length)}/${pending.length}`);
}
console.log(`MatchTruth historical bootstrap complete: ${total} facts imported.`);
