import { readFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { createWarehouse } from '../lib/warehouse.mjs';
import { parseOpenFootballPremierLeague } from '../lib/providers/openfootball.mjs';
const root = resolve(import.meta.dirname, '..');
const text = await readFile(join(root, 'data', 'raw', 'openfootball-england-2425.txt'), 'utf8');
const facts = parseOpenFootballPremierLeague(text, '2425', 'openfootball/england/2024-25');
const result = await createWarehouse(root).upsert(facts);
console.log(JSON.stringify({ imported: facts.length, ...result }));
