import { calculateMatch } from '../lib/multifactor-engine.mjs';
const league = { goals_home_mean: 1.48, goals_away_mean: 1.16, corners_mean: 9.55, cards_mean: 3.72 };
for (const key of ['xg_for','xg_against','shots_on_target','form_points','corners','cards']) league[key] = { mean: key === 'form_points' ? 1.3 : key === 'corners' ? 4.8 : key === 'cards' ? 1.9 : key === 'shots_on_target' ? 4.4 : 1.25, sd: key === 'form_points' ? .7 : key === 'corners' ? 1.7 : key === 'cards' ? .8 : key === 'shots_on_target' ? 1.5 : .4 };
const result = calculateMatch({ league, home:{xg_for:1.7,xg_against:.9,shots_on_target:5.5,form_points:2.1,corners:5.7,cards:1.5,lineup_strength:.25}, away:{xg_for:1.1,xg_against:1.5,shots_on_target:3.9,form_points:1.0,corners:4.1,cards:2.2,lineup_strength:-.1}, context:{home_advantage:1,rest_delta_days:2,weather:.1,pitch:.15,referee:.3} });
if (result.status !== 'calculated' || !Object.values(result.probabilities).every(x => x >= 0 && x <= 100)) throw new Error('multifactor engine test failed');
console.log(JSON.stringify(result, null, 2));
