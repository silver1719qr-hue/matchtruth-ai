/* Bulk factual history importer for automatic MatchTruth calculations. */
import { resolve } from 'node:path';
import { createWarehouse } from '../lib/warehouse.mjs';
import { importFootballHistory } from '../lib/football-history-import.mjs';

const root = resolve(import.meta.dirname, '..');
const warehouse = createWarehouse(root);
const result = await importFootballHistory(warehouse, event => console.log(event.error ? `${event.seasonCode}/${event.code}: skipped (${event.error})` : `${event.seasonCode}/${event.code}: ${event.imported} factual matches`));
console.log(`Football-data import complete: ${result.added} matches; ${result.sources} sources loaded.`);
