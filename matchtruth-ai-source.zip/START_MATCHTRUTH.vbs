' Normal use: double-click this file. It starts the updated server on a fresh
' local port, so an old stuck copy can never block the new version.
Option Explicit
Dim shell, fs, folder, serverCommand, nodePath, logPath
Set shell = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
folder = fs.GetParentFolderName(WScript.ScriptFullName)
' A double-clicked VBS does not always inherit the terminal PATH; use Node directly.
nodePath = "C:\Program Files\nodejs\node.exe"
logPath = folder & "\data\matchtruth-server.log"
' Replace an older copy first.  Without this, double-clicking after an update
' merely opens the browser against stale code already bound to port 8120.
shell.Run "cmd.exe /c for /f ""tokens=5"" %P in ('netstat -ano ^| findstr /R /C:"":8120 .*LISTENING""') do taskkill /PID %P /F >nul 2>&1", 0, True
WScript.Sleep 600
serverCommand = "cmd.exe /c cd /d """ & folder & """ && set PORT=8120 && """ & nodePath & """ server.mjs >> """ & logPath & """ 2>&1"
' Run hidden; it remains active while the MatchTruth server is running.
shell.Run serverCommand, 0, False
WScript.Sleep 1500
shell.Run "http://127.0.0.1:8120/", 1, False
